# ifndef INTERFACE_H_INCLUDED
# define INTERFACE_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

#include "lista.h"

void MSG_MENU(); // MENSAGEM PARA EXIBIR O MENU PRINCIPAL

void MENU(TLista *lista, TLista *lista2); // M�DULO DE MENU

# endif // INTERFACE_H_INCLUDED

